import { WebsiteType, Feature } from "@/components/InstantQuote";

// Price configuration
const priceConfig = {
  types: {
    "D2C": 300,
    "Portfolio/Agency": 400,
    "Consultation Platform": 450
  },
  features: {
    "Online Payment": 80,
    "Booking System": 100,
    "User Account": 70,
    "Admin Panel": 120,
    "Blog/Articles": 50,
    "Chat/Support System": 120,
    "Analytics Integration": 40,
    "Multi-language Support": 80
  }
};

export function calculatePrice(selectedType: WebsiteType, selectedFeatures: Feature[]): number {
  // Get base price for selected type
  const basePrice = priceConfig.types[selectedType];
  
  // Calculate additional cost for selected features
  const featuresPrice = selectedFeatures.reduce((total, feature) => {
    return total + priceConfig.features[feature];
  }, 0);
  
  // Return total price
  return basePrice + featuresPrice;
}

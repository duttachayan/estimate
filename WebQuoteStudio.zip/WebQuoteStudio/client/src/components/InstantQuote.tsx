import { useState, useEffect } from "react";
import TypeSelector from "./TypeSelector";
import FeatureSelector from "./FeatureSelector";
import PriceDisplay from "./PriceDisplay";
import { calculatePrice } from "@/lib/priceCalculator";

export type WebsiteType = "D2C" | "Portfolio/Agency" | "Consultation Platform";
export type Feature = 
  | "Online Payment" 
  | "Booking System" 
  | "User Account" 
  | "Blog/Articles" 
  | "Chat/Support System" 
  | "Analytics Integration"
  | "Admin Panel"
  | "Multi-language Support";

export default function InstantQuote() {
  const [selectedType, setSelectedType] = useState<WebsiteType>("D2C");
  const [selectedFeatures, setSelectedFeatures] = useState<Feature[]>([]);
  const [price, setPrice] = useState<number>(300);
  const [animatePrice, setAnimatePrice] = useState<boolean>(false);

  const handleTypeSelection = (type: WebsiteType) => {
    setSelectedType(type);
  };

  const handleFeatureSelection = (feature: Feature) => {
    setSelectedFeatures(prev => {
      const isSelected = prev.includes(feature);
      if (isSelected) {
        return prev.filter(f => f !== feature);
      } else {
        return [...prev, feature];
      }
    });
  };

  // Update price when selections change
  useEffect(() => {
    const newPrice = calculatePrice(selectedType, selectedFeatures);
    setPrice(newPrice);
    
    // Trigger animation
    setAnimatePrice(false);
    setTimeout(() => setAnimatePrice(true), 10);
  }, [selectedType, selectedFeatures]);

  return (
    <div className="glass-card bg-[hsl(var(--dark-card))] bg-opacity-80 rounded-xl shadow-xl w-full max-w-xl mx-auto overflow-hidden relative">
      <div className="p-6 sm:p-8">
        <h1 className="text-2xl sm:text-3xl font-semibold text-center mb-8 text-[hsl(var(--dark-accent))]">
          Instant Quote
        </h1>
        
        <TypeSelector 
          selectedType={selectedType} 
          onSelectType={handleTypeSelection} 
        />
        
        <FeatureSelector 
          selectedFeatures={selectedFeatures} 
          onSelectFeature={handleFeatureSelection} 
        />
        
        <PriceDisplay 
          price={price} 
          animate={animatePrice} 
        />
      </div>
    </div>
  );
}

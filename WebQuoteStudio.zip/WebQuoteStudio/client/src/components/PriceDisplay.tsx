import { cn } from "@/lib/utils";

interface PriceDisplayProps {
  price: number;
  animate: boolean;
}

export default function PriceDisplay({ price, animate }: PriceDisplayProps) {
  const displayPrice = price > 500 ? "$500+" : `$${price}`;
  
  return (
    <div className="text-center">
      <h2 
        className={cn(
          "text-4xl sm:text-5xl font-bold text-[hsl(var(--dark-accent))] mb-2",
          animate && "price-animate"
        )}
      >
        {displayPrice}
      </h2>
      <p className="text-[hsl(var(--dark-text-secondary))] text-sm max-w-md mx-auto">
        This is a rough estimate. Final pricing depends on your specific project requirements.
      </p>
    </div>
  );
}

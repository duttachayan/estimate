import { WebsiteType } from "./InstantQuote";

interface TypeSelectorProps {
  selectedType: WebsiteType;
  onSelectType: (type: WebsiteType) => void;
}

export default function TypeSelector({ selectedType, onSelectType }: TypeSelectorProps) {
  const types: WebsiteType[] = ["D2C", "Portfolio/Agency", "Consultation Platform"];

  return (
    <div className="mb-8">
      <h2 className="text-lg font-medium mb-4 text-center">Choose Type</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {types.map((type) => (
          <button
            key={type}
            onClick={() => onSelectType(type)}
            className={`option-btn py-3 px-4 rounded-lg font-medium border focus:outline-none focus:ring-2 focus:ring-[hsl(var(--dark-accent))/50] ${
              selectedType === type
                ? "bg-[hsl(var(--dark-selected))] text-[hsl(var(--dark-text-primary))] border-[hsl(var(--dark-accent))/30]"
                : "bg-[hsl(var(--dark-hover))] text-[hsl(var(--dark-text-secondary))] border-[hsl(var(--dark-hover))] hover:bg-[hsl(var(--dark-hover))] hover:border-[hsl(var(--dark-accent))/30] hover:text-[hsl(var(--dark-text-primary))] hover:shadow-[0_0_20px_rgba(196,167,121,0.15)]"
            }`}
          >
            {type}
          </button>
        ))}
      </div>
    </div>
  );
}

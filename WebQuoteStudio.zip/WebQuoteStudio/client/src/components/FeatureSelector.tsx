import { Feature } from "./InstantQuote";

interface FeatureSelectorProps {
  selectedFeatures: Feature[];
  onSelectFeature: (feature: Feature) => void;
}

export default function FeatureSelector({ selectedFeatures, onSelectFeature }: FeatureSelectorProps) {
  const features: Feature[] = [
    "Online Payment",
    "Booking System",
    "User Account",
    "Blog/Articles",
    "Chat/Support System",
    "Analytics Integration",
    "Admin Panel", 
    "Multi-language Support"
  ];

  return (
    <div className="mb-10">
      <h2 className="text-lg font-medium mb-4 text-center">Choose Extra Features</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {features.map((feature) => (
          <button
            key={feature}
            onClick={() => onSelectFeature(feature)}
            className={`option-btn py-3 px-4 rounded-lg font-medium border focus:outline-none focus:ring-2 focus:ring-[hsl(var(--dark-accent))/50] ${
              selectedFeatures.includes(feature)
                ? "bg-[hsl(var(--dark-selected))] text-[hsl(var(--dark-text-primary))] border-[hsl(var(--dark-accent))/30]"
                : "bg-[hsl(var(--dark-hover))] text-[hsl(var(--dark-text-secondary))] border-[hsl(var(--dark-hover))] hover:bg-[hsl(var(--dark-hover))] hover:border-[hsl(var(--dark-accent))/30] hover:text-[hsl(var(--dark-text-primary))] hover:shadow-[0_0_20px_rgba(196,167,121,0.15)]"
            }`}
          >
            {feature}
          </button>
        ))}
      </div>
    </div>
  );
}
